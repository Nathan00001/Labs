/*//=============================================================================
// PROGRAMMER: Nathan Scott
// PANTHER ID: 6274578
//
// CLASS: COP2210
// SECTION: Your class section:RVD
// SEMESTER: The current semester: Fall 2020
// CLASSTIME: Your COP2210 course meeting time : T/TH 9:00-10:15 am
//
// Project: Lab1
// DUE: 8/30/2020
//
// CERTIFICATION: I certify that this work is my own and that
// none of it is the work of any other person.
//=============================================================================
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package central;

/**
 *
 * @author Nathan
 */
import javax.swing.JFrame;

public class FaceViewer {
 

    /**
     *
     * @param args
     */
    public static void main(String[] args)
    {  
       JFrame frame = new JFrame();
       frame.setSize(150, 250);
       frame.setTitle("an Alien Face");
       frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
       FaceComponent component = new FaceComponent();
       frame.add(component);
       
       frame.setVisible(true);
               
               
    }
  }
    

