/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hardware;

/**
 *
 * @author Nathan
 */
public class VideoCard {
   private String memory;
   private int watts;
   private double price;
   private String manufacturer;
   
    
    public VideoCard(String manufacturer, String memory, int watts, double price){
        this.manufacturer = manufacturer;
        this.memory = memory;
        this.watts = watts;
        this.price = price;
        
        
    }
    
    
   //constructor

    /**
     *
     * @return 
     */
     
    
    
   public String getManufacturer(){
       return manufacturer;
       
   }
   public void setManufacturer(String manufacturer){
       this.manufacturer = manufacturer;
       
   }
   public String getMemory(){
       return memory;
   }
   public void setMemory(String memory){
       this.memory = memory;
   }
   
   public int getWatts(){
       return watts;
   }
   public void setWatts(int watts){
       this.watts = watts;
   }
   
   public double getPrice(){
       return price;
   }
   
   public void setPrice(double price){
       this.price = price;
   }
   
   public void displayInfo(){
       System.out.println("");
       System.out.println("===========================================");
       System.out.println("VideoCard Info");
       System.out.println("===========================================");
       System.out.printf("Mamufacturer:\t\t %-10s \n", manufacturer);
       System.out.printf("Momory:\t\t %-10s \n", memory);
       System.out.printf("Watts:\t\t\t %-10d \n", watts);
       System.out.printf("Price:\t\t\t %-10.2f \n", price);
   }
   
    
}
