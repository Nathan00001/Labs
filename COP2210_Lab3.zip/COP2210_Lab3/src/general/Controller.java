/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 *///=============================================================================
// PROGRAMMER: Nathan Scott Jr
// PANTHER ID: 6274578
//
// CLASS: COP2210
// SECTION: Your class section: RVD1208
// SEMESTER: The current semester: Fall2020
// CLASSTIME: Your COP2210 course meeting time :T/TH 9:00-10:15 am
//
// Project: Put what this project is: Lab 3
// DUE:September 13,2020
//
// CERTIFICATION: I understand FIU’s academic policies, and I certify that this work is my
// own and that none of it is the work of any other person.
//=============================================================================
package general;

import vehicle.Car;

/**
 *
 * @author Nathan
 */
public class Controller {
   
    
   
                    
    
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
           // create Car instance named c1 using default constructor 
           Car c1 = new Car("black", 2);
           
          
           
           // create car instance named c2  which is White and has 4 doors 
           Car c2 = new Car("white", 4);
           
           
          //create car instance named c3 which is red and has 2 doors 
           Car c3= new Car("red", 2);
          
           
          // create car instance named c4 which is green and as 6 doors 
           Car c4 = new Car("green", 6);
          
      
           
          // displayInfo on Instances
       
          c1.displayInfo();
          c2.displayInfo();
          c3.displayInfo();
          c4.displayInfo();
          
          
          
          
          
          
          System.out.println("/n");
          System.out.println("=====================");
          System.out.println("Car Class Info");
          System.out.println("=====================");
          System.out.println("vehicleCounter:\t\t" + Car.nextCarID    );
          System.out.println("CAR_FACTORY_ID:\t\t" + Car.getfactory());
          
          
          
    }
    
    
    
    
    
    

    
    
    
    }
          
           
      
           
           
      
    

    
    

