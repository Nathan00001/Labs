/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package central;

import hardware.CPU;
import hardware.Harddrive;
import hardware.Memory;
import hardware.VideoCard;
 


/**
 *
 * @author Nathan
 */
public class Computer {
   private CPU cpu;
   private Harddrive harddrive;
   private Memory memory;
   private VideoCard videoCard;
   
    
   
    
    public Computer(CPU cpu, Harddrive harddrive, Memory memory, VideoCard videoCard){
   this.cpu = cpu;
   this.harddrive = harddrive;
   this.memory = memory;
   this.videoCard = videoCard;
  
   
}
  
   
   public void displayInfo(){
       System.out.println("=================================");
       System.out.println("Computer Info");
       System.out.println("=================================");
       System.out.println("");
       cpu.displayInfo();
       memory.displayInfo();
       harddrive.displayInfo();
       videoCard.displayInfo();
       
       
      System.out.println("==================================");
      System.out.printf("Computer total price: \t %-10.2f \n", computerPrice()  );
   }
    
     private double computerPrice(){
          double  totalPrice = 0.0;
          totalPrice = cpu.getPrice() + harddrive.getPrice() + memory.getPrice() + videoCard.getPrice();
          
          
          return totalPrice;
     }
     
          
        
     
    
}
       
  
           
   

  
    
   
   
   
   
   
   
   
   
    

