//=============================================================================
// PROGRAMMER: Nathan SCott JR
// PANTHER ID: Y6274578
//
// CLASS: COP2210
// SECTION: Your class section: RVD
// SEMESTER: The current semester: Fall 2020
// CLASSTIME: Your COP2210 course meeting time : T/TH 9:00-10:15 am
//
// Project: Put what this project is: Lab 2
// DUE:Sept 6
//
// CERTIFICATION: I understand FIU’s academic policies, and I certify that this work is my
// own and that none of it is the work of any other person.
//=============================================================================/*

package general;

import static java.lang.Math.PI;

/**
 *
 * @author Nathan
 */
public class App {

    private static double intiallnvestmentValue;
    private static double diameter;
    private static double Math;
    private static String function;
    private static double C;
    
   
   
    
    

    /**
     * @param args the command line arguments
     * @param height
     * @param area
     */
    public static void main(String[] args, double height, String area) {
       
        

        //printing header
        System.out.println("");
        System.out.println("=============================");
        System.out.println("Investment values");
        System.out.println("=============================");
        
        double initiallnvestmentValue = 10000.00;
        
        double year1Return = 0.05;
        double year2Return = 0.07;
        
        double year1Value = intiallnvestmentValue * (1+year1Return);
        System.out.println("year1Value =" + year1Value);
        
        double year2Value = year1Value *(1 + year2Return);
        System.out.println("year2Value = " + year2Value);
        
        System.out.println("");
        System.out.println("=================================================");
        System.out.println("Step 6");
        System.out.println("=================================================");
       
        //Calcuate the area and perimeter of a square 
        System.out.println("");
        System.out.println("=================================================");
        System.out.println("step 7");
        System.out.println("=================================================");
        
        double sides = 12.547;
        double perimeter = sides*4;
        System.out.println("the perimeter of the square is" + perimeter +".");
        System.out.println("the area of the square is" + area +".");
   
        //Rectangle Printing
        System.out.println("");
        System.out.println("=================================================");
        System.out.println("step 8");
        System.out.println("=================================================");
        double side1 = 275.6421;
        double side2 = 55.23;
        System.out.println("the perimeter of the Rectangle is"+ perimeter + ".");
        System.out.println("the area of the Rectangle is "+ area +".");
        
        //Triangle Printing 
        System.out.println("");
        System.out.println("=================================================");
        System.out.println("step 9");
        System.out.println("=================================================");
        double B = 50.0;
        double A= 30.0;
        double C = Math.pow ((A*A + B*B), 0.5);
        perimeter = A + B + C;
        System.out.println("the perimeter of the triangle is"+ perimeter +".");
        System.out.println("the area of the triangle is"+ area +".");
        
        //Circle Printing
        System.out.println("");
        System.out.println("=================================================");
        System.out.println("Circle");
        System.out.println("=================================================");
        double diamiter = 20.562;
        double radius = diameter/2;
        double circumference = 2 * PI * radius;
        System.out.println("the circumference of the cirle is" + circumference+".");
        System.out.println("the area of the circle is" + area + ".");
        
        //Cylinder Printing
        System.out.println("");
        System.out.println("=================================================");
        System.out.println("Cylinder");
        System.out.println("=================================================");
        diameter =40.43;
        height = 120.54;
        radius = diameter/2;
        double area = (2*Math.PI*radius*height)+(2*Math.PI*(Math.pow (radius, 2)));
        System.out.println("." +"the cylinder surface area of the cylinder is" + area+".");
        double volume  = Math.PI * Math.pow (radius, 2) + height;
        System.out.println("the volume of the cylinder is"+ volume + ".");
        
        // Function Printing
        System.out.println("");
        System.out.println("=================================================");
        System.out.println("Function");
        System.out.println("=================================================");
        double x = 2.34;
        double y = 2.6;
        double z = 4.0;
        double result = (Math.pow(x,2.7)-Math.sqrt((23*z))/Math.sqrt(x*Math.pow(y, 2)))+(Math.pow(x, 3)/(3*x*Math.pow(y, -5.3)))+(19*x*y*z);
        System.out.println("the result of the function is" +function+ ".");
        
   
        
        
        
        
        
   
        
     
       
 }

    private static double Math(double radius, int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

  
     
    }
    







  