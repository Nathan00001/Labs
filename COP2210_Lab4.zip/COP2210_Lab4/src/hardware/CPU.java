/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hardware;

import java.util.Random;

/**
 *
 * @author Nathan
 */
 public class CPU {
   private String manufacturer;
   private  String frequency;
   private int cores;
   private  int watts;
   private double price;
    
   public CPU(String manufacturer, String frequency, int cores, int watts, double price){
   this.manufacturer = manufacturer;
   this.frequency = frequency;
   this.cores = cores;
   this.watts = watts;
   this.price = price;
   }
   



//constructor//
   
 

    /**
     *
     * @return
     */
    public String getManufacturer(){
       return manufacturer;
       
   }
   public  void setManufacturer(String manufacturer){
       this.manufacturer = manufacturer;
   }
   
   public String getFrequency(){
       return frequency;
   }
   public void setFrequency(String frequency){
       this.frequency = frequency;
   }
   
   public int getCores(){
       return cores;
   }
   public void setCores(int cores){
       this.cores = cores;
   }
   
   public int getWatts(){
       return watts;
   }
   public double getPrice(){
       return price;
   }
   
   public void setPrice(double price){
       this.price = price;

  
    }
   
   public void displayInfo(){
       System.out.println("");
       System.out.println("=========================================");
       System.out.println("CPU Info");
       System.out.println("=========================================");
       System.out.printf("Manufacturer:\t\t %-10s \n", manufacturer);
       System.out.printf("Frequency:\t\t %-10s \n", frequency);
       System.out.printf("Cores:\t\t\t %-10d \n", cores);
       System.out.printf("Watts:\t\t\t %-10d \n", watts);
       System.out.printf("Price:\t\t\t %-10.2f \n", price);
   }
 }
        
 
    

        
   


