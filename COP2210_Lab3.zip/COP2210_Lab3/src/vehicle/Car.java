/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 *///=============================================================================
// PROGRAMMER: Nathan Scott Jr
// PANTHER ID: 6274578
//
// CLASS: COP2210
// SECTION: Your class section: RVD1208
// SEMESTER: The current semester: Fall2020
// CLASSTIME: Your COP2210 course meeting time : T/TH 9:00-10:15 am
//
// Project: Put what this project is: Lab3
// DUE:September 13, 2020
//
// CERTIFICATION: I understand FIU’s academic policies, and I certify that this work is my
// own and that none of it is the work of any other person.
//=============================================================================
package vehicle;

import java.util.Random;


/**
 *
 * @author Nathan
 */
public class Car { 
    //-----------------------------
    // class and variables
    //----------------------------
    
    public static  int nextCarID = 1001;
    public final static String factory = "michigan";

    
    

   
    // Instances
    public String color;
    public  int ID;
    private  int numberOfDoors;
    private int price;
    public String car;
   
    
    
    
    
    
    
    // Default car
    public Car(){
    
    this.color = "Black";
    numberOfDoors = 2;
    
    
    //range from $25000  to $30000
    Random ranGen = new Random();
    int dollars = ranGen.nextInt(5000) + 25000;
    price = dollars;
     
    ID = nextCarID;
    nextCarID++;
    
    
    
    
    
    
     }
    
    
    
    
    // Counstructor 
    public Car( String color, int numberOfDoors){
        this.color= color;
   
    this.color = color;
    this.numberOfDoors = numberOfDoors;
    }
    
    
    
    //Class method
    public static int getnextCarID(){
        return nextCarID;
    }
    
    public  void nextCarID(int nextCarID){
      Car.nextCarID = nextCarID;
    }
    
   public String getColor() {
        return color;
     
    
}
    public void setColor(String color){
        this.color = color;
        
    }
    
      public static String getfactory(){
           return factory;
       }
      
            public String getCar(){
               return car;
           }
         public int getprice(){
           return price;
           
}
       public void setPrice(int price){
           this.price = price;
       }
        
    /**
     *
     * @param nextCarID
     */
    public void setnextCarID(int nextCarID){
          this.nextCarID = nextCarID;
         
          
          
          
        }
    
  
         
           
           
           
         
        
        
 
    

    
    
        
        
 
    

    
    

    /**
     *
     */
    public void displayInfo(){
    System.out.println("===================================");
    System.out.println("Car information");   
    System.out.println("===================================");
    System.out.println("nextCarID:\t\t" + nextCarID);
    System.out.println("Factory:\t\t" + factory);
    System.out.println("Numberofdoors:\t\t" + numberOfDoors);
    System.out.println("Color:\t\t" + color);
    System.out.println("Price:\t\t" + price);
    System.out.println("/n");
    } 

   

   
        
           
        
    

    
   
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
   
    
    
    
    
    
    
    
    
     
     
     
     
}
            
    

   
        
        
   
    
            
    
    
   
         
 
    

