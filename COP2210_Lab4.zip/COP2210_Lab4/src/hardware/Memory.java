/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hardware;

/**
 *
 * @author Nathan
 */
public class Memory {
 private String manufacturer;
 private String speed;
 private double price;
 private String size;
 
 public Memory(String manufacturer, String speed, String size, double price){
     this.manufacturer = manufacturer;
     this.price = price;
     this.size = size;
     this.speed = speed;
     
 }
 //contructor 
 
 
     
 
 public String getManufacturer(){
     return manufacturer;
 }
 public void setManufacturer(String manufacturer){
     this.manufacturer = manufacturer;
 }
 public String getSpeed(){
     return speed;
 }
 public void setSpeed(String speed){
     this.speed = speed;
 }
 public double getPrice(){
     return price;
     
 }
 public void setPrice(double price){
     this.price = price;
 } 
    public void displayInfo(){
        System.out.println("");
        System.out.println("===========================================");
        System.out.println("Memory Info");
        System.out.println("===========================================");
        System.out.printf("Manufacturer:\t\t %-10s \n",manufacturer );
        System.out.printf("Speed:\t\t\t %-10s \n", speed);
        System.out.printf("Price:\t\t\t %-10.2f \n", price);
    }
} 
        
