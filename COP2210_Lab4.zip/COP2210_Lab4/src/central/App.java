/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 *///=============================================================================
// PROGRAMMER: NATHAN SCOTT JR
// PANTHER ID: 6274578
//
// CLASS: COP2210
// SECTION: Your class section: RVD
// SEMESTER: The current semester:Fall 2020
// CLASSTIME: Your COP2210 course meeting time :example T/TH 9:00-10:15 am
//
// Project: Put what this project is: Lab 4
// DUE:
//
// CERTIFICATION: I understand FIU’s academic policies, and I certify that this work is my
// own and that none of it is the work of any other person.
//=============================================================================
package central;

import hardware.CPU;
import hardware.Harddrive;
import hardware.Memory;
import hardware.VideoCard;



/**
 *
 * @author Nathan
 */
public class App {

    private static Object computer;
    
   

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     CPU cpu1 = new CPU("AMD", "3.9GHz", 6, 65, 165.99);
     Harddrive harddrive1 = new Harddrive("Western Digital", "SATA 6 Gb/s", 64, 3.5, 44.89);
     Memory memory1 = new Memory("G.Skill", "DDR4-3200", "16GB", 169.99);
     VideoCard videoCard1 = new VideoCard("Asus", "11GB", 250, 799.99);
     Computer computer1 = new Computer(cpu1, harddrive1, memory1, videoCard1); 
     
     computer1.displayInfo();
    
  
         
     }

   
     
     
    }
  
    

